package com.demo.dao.service;

import com.demo.pojo.User;

public interface UserDAO {
	public User getUserByUsername(String username);
}
